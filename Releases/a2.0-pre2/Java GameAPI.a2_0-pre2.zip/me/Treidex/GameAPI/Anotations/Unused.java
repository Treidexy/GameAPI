package me.Treidex.GameAPI.Anotations;

public @interface Unused {}