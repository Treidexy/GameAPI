package me.Treidex.GameAPI.Anotations;

/**
 * Just what it says.
 * Something's Not Finished yet.
 * 
 * @author Treidex
 *
 */
public @interface Unfinished {}