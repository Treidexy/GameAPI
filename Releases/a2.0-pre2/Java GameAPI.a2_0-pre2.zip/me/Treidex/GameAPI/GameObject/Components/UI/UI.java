package me.Treidex.GameAPI.GameObject.Components.UI;

import me.Treidex.GameAPI.GameObject.Components.Component;

public abstract class UI extends Component {}