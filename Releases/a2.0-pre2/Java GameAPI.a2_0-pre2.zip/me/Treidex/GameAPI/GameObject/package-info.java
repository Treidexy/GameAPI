/**
 * Used for anything Related to Game Objects.
 */
package me.Treidex.GameAPI.GameObject;