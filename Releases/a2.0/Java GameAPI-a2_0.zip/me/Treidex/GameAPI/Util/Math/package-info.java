/**
 * Main Package for Custom Math.
 * Including Vector2 (At Least a simple version of it),
 * and Mathf (Addition to Math).
 */
package me.Treidex.GameAPI.Util.Math;