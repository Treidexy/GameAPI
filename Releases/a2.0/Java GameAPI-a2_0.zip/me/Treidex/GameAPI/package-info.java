/**
 * Main Directory for the Game API;
 * Use this as base for imports.
 */
package me.Treidex.GameAPI;