package me.Treidex.GameAPI.GameObject.Components.UI;

import me.Treidex.GameAPI.GameObject.Components.Component;

/**
 * 
 * Super Class for all UI Components.
 * 
 * @author Treidex
 *
 */
public abstract class UI extends Component {}