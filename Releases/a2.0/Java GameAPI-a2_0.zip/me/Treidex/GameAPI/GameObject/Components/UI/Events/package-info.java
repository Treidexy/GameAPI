/**
 * Package for all User Interface Events.
 */
package me.Treidex.GameAPI.GameObject.Components.UI.Events;