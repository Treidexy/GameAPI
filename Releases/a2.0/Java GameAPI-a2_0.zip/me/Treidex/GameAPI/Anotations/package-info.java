/**
 * Annotations! Everyone loves Annotations!!!
 */
package me.Treidex.GameAPI.Anotations;